process.env.NODE_ENV = 'test';

var app = require('../server.js');
var supertest = require("supertest");
var should = require("should");
var server = supertest.agent(app);
var port = process.env.PORT || 8081;

function importTest(name, path) {
  describe(name, function () {
    require(path)(server);
  });
}

describe('API test', function() {
  //importTest('Sign up test', './signup.test.js');
  //importTest('Login test', './login.test.js');
  //importTest('User test', './user.test.js');
  //importTest('Branch test', './branch.test.js');
  //importTest('SubBranch test', './subbranch.test.js');
  //importTest('Post test', './post.test.js');
});
